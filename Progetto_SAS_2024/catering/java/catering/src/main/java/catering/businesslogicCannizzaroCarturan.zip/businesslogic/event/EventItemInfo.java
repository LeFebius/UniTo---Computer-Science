package catering.businesslogic.event;

public interface EventItemInfo {
}
